
int leerEnteroPositivo(char* mensaje);
int leerEntero(char* mensaje);
int leerEnteroEntre(char* mensaje, int min, int max);
int leerenteromayorigual(char* mensaje, int limite);
float leerFlotante(char* mensaje);
float leerFlotantePositivo(char* mensaje);
float leerFlotanteEntre(char* mensaje, float min, float max);
float leerflotantemayorigual(char* mensaje, float limite);
char leerCaracter(char* mensaje);
