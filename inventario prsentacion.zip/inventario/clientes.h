
int esCedulaValida(const char *cedula);
void agregarCliente(char cedulas[][11], char nombres[][50], int *contador, int maxClientes);
void modificarCliente(char cedulas[][11], char nombres[][50], int contador);
void consultarCliente(char cedulas[][11], char nombres[][50], int contador);
void listarClientes(char cedulas[][11], char nombres[][50], int contador);
void eliminarCliente(char cedulas[][11], char nombres[][50], int *contador);
void cargarClientes(char cedulas[][11], char nombres[][50], int *contador, const char *nombreArchivo);
void guardarClientes(char cedulas[][11], char nombres[][50], int contador, const char *nombreArchivo);


