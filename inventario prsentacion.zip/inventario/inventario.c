#include <stdio.h>
#include <string.h>
#include "inventario.h"

void cargarProductos(char nombres[][50], int cantidades[], float precios[], int *contador, const char *nombreArchivo) {
    FILE *archivo = fopen(nombreArchivo, "r");
    if (!archivo) {
        printf("No se pudo abrir el archivo de productos.\n");
        return;
    }

    while (fscanf(archivo, "%s %d %f", nombres[*contador], &cantidades[*contador], &precios[*contador]) != EOF) {
        (*contador)++;
    }

    fclose(archivo);
}

void agregarProducto(char nombres[][50], int cantidades[], float precios[], int *contador, int maxProductos) {
    if (*contador >= maxProductos) {
        printf("No se pueden agregar más productos.\n");
        return;
    }

    printf("Ingresando un nuevo producto:\n");
    printf("Nombre del producto: ");
    scanf("%s", nombres[*contador]);
    printf("Cantidad del producto: ");
    scanf("%d", &cantidades[*contador]);
    printf("Precio del producto: ");
    scanf("%f", &precios[*contador]);

    (*contador)++;
    printf("Producto ingresado correctamente.\n");
}

void mostrarProductos(char nombres[][50], int cantidades[], float precios[], int contador) {
    printf("Listado de productos:\n");
    for (int i = 0; i < contador; i++) {
        printf("Nombre: %s, Cantidad: %d, Precio: %.2f\n", nombres[i], cantidades[i], precios[i]);
    }
}

void buscarProducto(char nombres[][50], int cantidades[], float precios[], int contador) {
    char nombre[50];
    printf("Ingrese el nombre del producto a buscar: ");
    scanf("%s", nombre);

    for (int i = 0; i < contador; i++) {
        if (strcmp(nombres[i], nombre) == 0) {
            printf("Nombre: %s, Cantidad: %d, Precio: %.2f\n", nombres[i], cantidades[i], precios[i]);
            return;
        }
    }

    printf("Producto no encontrado.\n");
}

void editarProducto(char nombres[][50], int cantidades[], float precios[], int contador) {
    char nombre[50];
    printf("Ingrese el nombre del producto a editar: ");
    scanf("%s", nombre);

    for (int i = 0; i < contador; i++) {
        if (strcmp(nombres[i], nombre) == 0) {
            printf("Ingrese la nueva cantidad: ");
            scanf("%d", &cantidades[i]);
            printf("Ingrese el nuevo precio: ");
            scanf("%f", &precios[i]);
            printf("Producto editado correctamente.\n");
            return;
        }
    }

    printf("Producto no encontrado.\n");
}

void adicionarCompraProducto(char nombres[][50], int cantidades[], float precios[], int *contador, int maxProductos) {
    if (*contador >= maxProductos) {
        printf("No se pueden agregar más productos.\n");
        return;
    }

    printf("Adicionando una compra de producto:\n");
    printf("Nombre del producto: ");
    scanf("%s", nombres[*contador]);
    printf("Cantidad del producto: ");
    scanf("%d", &cantidades[*contador]);
    printf("Precio del producto: ");
    scanf("%f", &precios[*contador]);

    (*contador)++;
    printf("Compra de producto adicionada correctamente.\n");
}

void eliminarProducto(char nombres[][50], int cantidades[], float precios[], int *contador) {
    char nombre[50];
    printf("Ingrese el nombre del producto a eliminar: ");
    scanf("%s", nombre);

    for (int i = 0; i < *contador; i++) {
        if (strcmp(nombres[i], nombre) == 0) {
            for (int j = i; j < *contador - 1; j++) {
                strcpy(nombres[j], nombres[j + 1]);
                cantidades[j] = cantidades[j + 1];
                precios[j] = precios[j + 1];
            }
            (*contador)--;
            printf("Producto eliminado correctamente.\n");
            return;
        }
    }

    printf("Producto no encontrado.\n");
}

void guardarProductos(char nombres[][50], int cantidades[], float precios[], int contador, const char *nombreArchivo) {
    FILE *archivo = fopen(nombreArchivo, "w");
    if (!archivo) {
        printf("No se pudo abrir el archivo de productos.\n");
        return;
    }

    for (int i = 0; i < contador; i++) {
        fprintf(archivo, "%s %d %.2f\n", nombres[i], cantidades[i], precios[i]);
    }

    fclose(archivo);
}
